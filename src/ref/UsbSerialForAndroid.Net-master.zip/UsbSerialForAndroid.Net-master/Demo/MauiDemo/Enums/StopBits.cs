﻿namespace MauiDemo.Enums;

public enum StopBits
{
    None = 0,
    One = 1,
    OnePointFive = 3,
    Two = 2,
}