﻿namespace UsbSerialForAndroid.Net.Enums
{
    public enum StopBits
    {
        None = 0,
        One = 1,
        Two = 2,
        OnePointFive = 3,
    }
}
