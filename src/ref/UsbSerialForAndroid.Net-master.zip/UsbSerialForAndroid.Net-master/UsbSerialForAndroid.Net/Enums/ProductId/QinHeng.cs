﻿namespace UsbSerialForAndroid.Net.Enums
{
    /// <summary>
    /// QinHeng Electronics
    /// </summary>
    public enum QinHeng
    {
        HL340 = 0x7523,
        CH341A = 0x5523,
    }
}
