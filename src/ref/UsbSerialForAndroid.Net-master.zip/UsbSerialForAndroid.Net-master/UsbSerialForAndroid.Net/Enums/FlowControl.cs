﻿namespace UsbSerialForAndroid.Net.Enums
{
    public enum FlowControl
    {
        NONE,
        RTS_CTS,
        DTR_DSR,
        XON_XOFF,
        XON_XOFF_INLINE
    }
}
