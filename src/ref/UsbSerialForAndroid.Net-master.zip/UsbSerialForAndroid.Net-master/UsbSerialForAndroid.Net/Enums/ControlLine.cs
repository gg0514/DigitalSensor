﻿namespace UsbSerialForAndroid.Net.Enums
{
    public enum ControlLine
    {
        RTS,
        CTS,
        DTR,
        DSR,
        CD,
        RI
    }
}
