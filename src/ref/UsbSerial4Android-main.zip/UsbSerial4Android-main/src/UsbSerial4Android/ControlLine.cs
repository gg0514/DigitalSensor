﻿namespace UsbSerial4Android;

public enum ControlLine { RTS, CTS, DTR, DSR, CD, RI }
