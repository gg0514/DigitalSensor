# usb-serial-for-android-net
This library is a C# version of [usb-serial-for-android](https://github.com/mik3y/usb-serial-for-android).
It is a work in progress and used for private needs.
