﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Reddilonia.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}
