﻿using Avalonia.Controls;

namespace Reddilonia.Views;

public partial class PostView : UserControl
{
    public PostView()
    {
        InitializeComponent();
    }
}
