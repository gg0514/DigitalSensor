﻿using Avalonia.Controls;

namespace Reddilonia.Views;

public partial class PostListView : UserControl
{
    public PostListView()
    {
        InitializeComponent();
    }
}

