﻿using Avalonia.Controls;

namespace Reddilonia.Views;

public partial class FeedsView : UserControl
{
    public FeedsView()
    {
        InitializeComponent();
    }
}
