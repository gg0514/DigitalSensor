﻿using Avalonia.Controls;

namespace Reddilonia.Views;

public partial class SubRedditView : UserControl
{
    public SubRedditView()
    {
        InitializeComponent();
    }
}
