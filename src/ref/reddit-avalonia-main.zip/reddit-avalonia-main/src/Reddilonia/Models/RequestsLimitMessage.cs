﻿namespace Reddilonia.Models;

public record RequestsLimitMessage(int RequestsDone, int RequestsTotal);
