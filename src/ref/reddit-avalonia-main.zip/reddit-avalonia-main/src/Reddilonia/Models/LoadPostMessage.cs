﻿using Reddit.Client.Dtos;

namespace Reddilonia.Models;

public record LoadPostMessage(Post Post);
