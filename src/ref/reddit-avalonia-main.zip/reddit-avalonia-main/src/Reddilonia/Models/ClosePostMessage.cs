﻿namespace Reddilonia.Models;

public record ClosePostMessage;
