﻿namespace Reddilonia.Models;

public record ReloadFeedsViewMessage;
